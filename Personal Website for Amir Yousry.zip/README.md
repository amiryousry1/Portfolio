
  # Personal Website for Amir Yousry

  This is a code bundle for Personal Website for Amir Yousry. The original project is available at https://www.figma.com/design/kbKhAIRMdrBvBPEiosEood/Personal-Website-for-Amir-Yousry.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  